package com.uta.eprescription;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.uta.eprescription.Doctor_page;
import com.uta.eprescription.Pharmacist_page;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn = (Button)findViewById(R.id.button_sign_in);
        final EditText txtname = (EditText)findViewById(R.id.User_id);
        final EditText pass = (EditText)findViewById(R.id.login_password);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(txtname.getText().toString().equals("doctor") && pass.getText().toString().equals("password")) {
                    startActivity(new Intent(MainActivity.this, Doctor_page.class)); }
                else if(txtname.getText().toString().equals("pharmacist") && pass.getText().toString().equals("password")){
                    startActivity(new Intent(MainActivity.this, Pharmacist_page.class));
                }
                else{
                    AlertDialog alert = new AlertDialog.Builder(MainActivity.this).create();
                    alert.setTitle("Alert");
                    alert.setMessage("Incorrect Username/Password");
                    alert.setButton("OK", new DialogInterface.OnClickListener() {

                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub

                        }
                    });
                    alert.show();
                }
            }

        });
    }
}
